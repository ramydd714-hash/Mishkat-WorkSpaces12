
export const COLORS = {
  primary: '#1e40af', // Blue 800
  secondary: '#1e293b', // Slate 800
  accent: '#f8fafc', // Slate 50
  text: '#1e293b',
  bg: '#f8fafc'
};
